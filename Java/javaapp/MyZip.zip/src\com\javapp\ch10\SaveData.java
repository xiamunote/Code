package com.javapp.ch10;
import java.io.*;
import java.util.*;
import java.util.zip.*;
public class ZipCompress {
	public static void main(String[] args) throws IOException {
		if (args.length == 0) {
			args = new String[2];
			args[0] = "src\\com\\javapp\\ch10\\ZipCompress.java";
			args[1] = "src\\com\\javapp\\ch10\\SaveData.java";
		}
		FileOutputStream file = new FileOutputStream("MyZip.zip");
		CheckedOutputStream ckfile = new CheckedOutputStream(file,new Adler32());
		ZipOutputStream zipos = new ZipOutputStream(ckfile);
		BufferedOutputStream out = new BufferedOutputStream(zipos);
		zipos.setComment("JAVA �)�:");
		for (int i = 0; i < args.length; i++) {
			System.out.println("�e�� " + args[i]);
			BufferedReader in = new BufferedReader(new FileReader(args[i]));
			zipos.putNextEntry(new ZipEntry(args[i]));
			int c;
			while ((c = in.read()) != -1) {
				out.write(c);
			}
			in.close();
		}
		out.close();
		System.out.println("Checksum: " + ckfile.getChecksum().getValue());
		//  �gL��:
		System.out.println("c(�և�");
		FileInputStream fi = new FileInputStream("MyZip.zip");
		CheckedInputStream csumi = new CheckedInputStream(fi,new Adler32());
		ZipInputStream in2 = new ZipInputStream(csumi);
		BufferedInputStream bis = new BufferedInputStream(in2);
		ZipEntry ze;
		while ((ze = in2.getNextEntry()) != null) {
			System.out.println("�և�: " + ze);
			int i_read;
			while ((i_read = bis.read()) != -1) {
				System.out.write(i_read);
			}
		}
		System.out.println("Checksum: " + csumi.getChecksum().getValue());
		bis.close();
		ZipFile zf = new ZipFile("MyZip.zip");
		Enumeration e = zf.entries();
		while (e.hasMoreElements()) {
			ZipEntry ze2 = (ZipEntry) e.nextElement();
			System.out.println("��: " + ze2);
		}
}
}
package com.javapp.ch10;
import java.io.*;
class SaveData implements Serializable{
private static final long serialVersionUID = 1L;
String name,addr;
int age;
    public SaveData(String name,String addr ,int age){
        this.name=name;
        this.addr=addr;
        this.age=age;
    }
    public String toString(){
        return " �"+name+" O@"+addr+" t�:"+Integer.toString(age)  ;
    }
}
