import javax.swing.JFrame;

public class Client
{
	public static void main(String[] args)
	{
		Mains frame = new Mains();
		frame.setSize(690,400);
		frame.setResizable(true);
		frame.setTitle("���յ���Ʊ���ۺϹ���ϵͳ");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
