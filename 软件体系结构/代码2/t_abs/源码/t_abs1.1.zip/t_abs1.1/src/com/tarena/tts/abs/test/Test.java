package com.tarena.tts.abs.test;

/**
 * @ file_name Test.java
 * @ author baiyx (baiyx@tarena.com.cn)
 * @ date May 29, 20121:46:10 PM
 * @ description
 * @ reviewed_by 
 */
public class Test {
	
	public static void main(String[] args) {
		String s = "abc_xiaoxiao";
		
		String s1 = s.substring(s.lastIndexOf("_"), s.length());
		System.out.println(s1);
	}
}
