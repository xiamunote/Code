package com.javapp.ch18;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Mains extends JFrame
{
    private UpdateComboBox update;
    private FlightAppFrame jiemian;
    Mains()
	{
		update = new UpdateComboBox();
		jiemian = new FlightAppFrame();
		this.getContentPane().add(jiemian);		
	}
}