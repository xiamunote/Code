package com.tarena.tts.abs.util;

import java.text.NumberFormat;

/**
 * @ file_name NumberUtil.java
 * @ author baiyx (baiyx@tarena.com.cn)
 * @ date Apr 27, 20125:23:01 PM
 * @ description
 * @ reviewed_by 
 */
public class NumberUtil {
	
	public static String format(int i){
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMinimumIntegerDigits(2);
		return nf.format(i);
	}
}	
