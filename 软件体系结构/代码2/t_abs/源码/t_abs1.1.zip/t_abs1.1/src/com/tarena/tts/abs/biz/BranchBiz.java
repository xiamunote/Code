package com.tarena.tts.abs.biz;

import java.sql.SQLException;
import java.util.List;
import com.tarena.tts.abs.vo.Branch01;

/**
 * 营业网点业务对象
 * @ file_name Branch.java
 * @ author baiyx (baiyx@tarena.com.cn)
 * @ date May 14, 20122:38:21 PM
 * @ description
 * @ reviewed_by 
 */
public interface BranchBiz {
	
	public List<Branch01>  findBranch() throws SQLException;
}
