package com.tarena.tts.abs.dao;

import java.sql.SQLException;
import java.util.List;

import com.tarena.tts.abs.entity.TicketOrder;

public interface OrderdetailDAO {

	public List<Object[]> findOrderdetail(Long orderId) throws SQLException;

	public List<TicketOrder> findTicketOrder(Long orderId) throws Exception;

}
